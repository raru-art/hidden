// HIDDEN の設定ファイル(このファイルだけ編集すれば設定できます)
window.HIDDEN_CONFIG = {
  // Firebaseコンソールで取得した Web アプリの設定値を貼り付ける。null のままならデモモード。
  // 例: firebase: { apiKey: "...", authDomain: "...", projectId: "...", appId: "..." },
  firebase: null,
  // 利用規約・プライバシーポリシーに表示する運営者情報(公開前に必ず設定)
  operator: { name: "", contact: "" }
};
